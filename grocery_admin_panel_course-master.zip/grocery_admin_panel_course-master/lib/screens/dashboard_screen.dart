import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:d_chart/d_chart.dart';
import 'package:flutter/material.dart';
import 'package:grocery_admin_panel/providers/orderSales.dart';
import 'package:grocery_admin_panel/services/utils.dart';
import 'package:grocery_admin_panel/widgets/text_widget.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import '../providers/userStatistic.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';

import '../widgets/commentList.dart';

class DashboardScreen extends StatefulWidget {
   DashboardScreen({Key? key}) : super(key: key);

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}
class _DashboardScreenState extends State<DashboardScreen> {
  static List<OrderSales> _orders = [];
  static List<UserStats> _users = [];
  static List<double> ratings = [];
  List<UserStats> usersStats = [];
  List<OrderSales> processedData = [];
  late String orderDateStr;
  int? cancelled = 2;
  int? delivered = 2;
  int? orders = 2;
  int? pending = 2;
  double? rating = 0.0;
  int? cart;
  num allSales = 0;
  RegExp reg = RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))');
  String Function(Match) mathFunc = (Match match) => '${match[1]},';

  void initState() {

    /*salesRecord();*/
    ratings.clear();
    processedData.clear();
    _orders.clear();
    usersStats.clear();
    _users.clear();
    getStatistics();
    DateTime now = DateTime.now();
    String formattedTime = DateFormat.MEd().format(now);
    DateTime dateToday = DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day);
    String w = '${DateFormat.yMd().format(now)} ';
    print(formattedTime);
    print(w);
    print(dateToday);

    super.initState();
  }
   Future getStatistics() async {
     if (cancelled == 0) {
       return Container(
           alignment: FractionalOffset.center,
           child: CircularProgressIndicator());
     }else{
       await FirebaseFirestore.instance
           .collection("orders")
           .where('cancelled',whereIn:[true])
           .get()
           .then((snapshot) => {
         cancelled = snapshot.docs.length
       });
     }
     if (delivered == 0) { // if snapshot has no data this is going to run
       return Container(
           alignment: FractionalOffset.center,
           child: CircularProgressIndicator());
     }else{ // if snapshot has data this is going to run
       await FirebaseFirestore.instance
           .collection("orders")
           .where('delivered',whereIn:[true])
           .get()
           .then((snapshot) => {
         delivered = snapshot.docs.length
       });
     }
     await FirebaseFirestore.instance
        .collection("orders")
        .get()
        .then((snapshot) => {
      orders = snapshot.docs.length
    });
     pending = orders! - delivered! - cancelled!;

     await FirebaseFirestore.instance
         .collection("orders")
         .where('delivered',whereIn:[true])
         .get()
         .then((snapshot) => {
   snapshot.docs.forEach((element) {
         _orders.insert(
           0,
          OrderSales(price: element.get('price'), orderDate: element.get('orderDate').toDate())
         );
       })

     });
     _orders.sort((a,b) {
       var adate = a.orderDate; //before -> var adate = a.expiry;
       var bdate = b.orderDate;//var bdate = b.expiry;
       return -adate.compareTo(bdate);
     });

     for (var dailySales in _orders) {
       num sales = 0;

       final dailyFormat = DateFormat("dd-MM-yyyy").format(dailySales.orderDate);

       for (int i = 0; i < _orders.length; i++) {

         final dateFromData = DateFormat("dd-MM-yyyy").format(_orders[i].orderDate);

         if (dateFromData == dailyFormat) {
           sales += _orders[i].price;
         }
       }
       processedData.insert(0,OrderSales(orderDate: DateFormat("dd-MM-yyyy").parse(dailyFormat), price: sales));
     }
     final Map<DateTime, OrderSales> map = {
       for (var dailySales in processedData) dailySales.orderDate : dailySales,
     };
     processedData = map.values.toList();

       for (var dailySales in _orders) {
         num saless = 0;
         for (int i = 0; i < _orders.length; i++) {
             saless += _orders[i].price;
         }
           allSales = saless;
       }
       String result = allSales.toString().replaceAllMapped(reg, mathFunc);
       print(allSales);


     await FirebaseFirestore.instance
         .collection("users")
         .get()
         .then((snapshot) => {
       snapshot.docs.forEach((element) {
         _users.insert(
             0,
             UserStats(users: 1, createdAt: element.get('createdAt').toDate())
         );
       })
     });
     await FirebaseFirestore.instance
         .collection("feedback")
         .get()
         .then((snapshot) => {
       snapshot.docs.forEach((element) {
        /* _users.insert(
             0,
             UserStats(users: 1, createdAt: element.get('createdAt').toDate())
         );*/
         ratings.insert(0, element.get('rating'));
       })
     });
     for (var dailySales in ratings) {
       double saless = 0.0;
       for (int i = 0; i < ratings.length; i++) {
         saless += ratings[i];

       }
       rating = saless / ratings.length;
     }

     _users.sort((a,b) {
       var adate = a.createdAt; //before -> var adate = a.expiry;
       var bdate = b.createdAt;//var bdate = b.expiry;
       return -adate.compareTo(bdate);
     });

     for (var dailySales in _users) {
       int sales = 0;

       final dailyFormat = DateFormat("dd-MM-yyyy").format(dailySales.createdAt);

       for (int i = 0; i < _users.length; i++) {

         final dateFromData = DateFormat("dd-MM-yyyy").format(_users[i].createdAt);

         if (dateFromData == dailyFormat) {
           sales += _users[i].users;
         }
       }
      usersStats.insert(0,UserStats(createdAt: DateFormat("dd-MM-yyyy").parse(dailyFormat), users: sales));
     }
     final Map<DateTime, UserStats> maps = {
       for (var dailySales in usersStats) dailySales.createdAt : dailySales,
     };
     usersStats = maps.values.toList();
     print(usersStats.toList());


   }



  @override
  Widget build(BuildContext context) {
    MediaQueryData queryData;
    queryData = MediaQuery.of(context);
    Size size = Utils(context).getScreenSize;
    Color color = Utils(context).color;

    return SafeArea(
      child: SingleChildScrollView(
        controller: ScrollController(),
        padding: const EdgeInsets.all(30),
        child: Column(

          children: [
            /*Header(
              fct: () {
                menuProvider.controlDashboarkMenu();
              },
            ),*/
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Expanded(
                    // flex: 5,
                    child: Card(
                      color: Theme.of(context).cardColor,
                      child: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: SfCartesianChart(
                                primaryXAxis: CategoryAxis(),
                                // Chart title
                                title: ChartTitle(text: 'Daily Sales'),
                                // Enable legend
                                legend: Legend(isVisible: true),
                                // Enable tooltip
                                tooltipBehavior: TooltipBehavior(enable: true),
                                series: <ChartSeries<OrderSales, String>>[
                                  LineSeries<OrderSales, String>(
                                      dataSource: processedData,
                                      xValueMapper: (OrderSales sales, _) => '${DateFormat("MMM dd").format(sales.orderDate)} ',
                                      yValueMapper: (OrderSales sales, _) => sales.price,
                                      name: 'Line',
                                      color: Colors.orangeAccent,
                                      // Enable data label
                                      dataLabelSettings: DataLabelSettings(isVisible: true)),
                                  ColumnSeries(dataSource: processedData,
                                    xValueMapper: (OrderSales sales, _) => '${DateFormat("MMM dd").format(sales.orderDate)} ',
                                    yValueMapper: (OrderSales sales, _) => sales.price,
                                    name: 'Column',
                                    color: Colors.red,
                                      selectionBehavior: SelectionBehavior(
                                          enable: true,
                                          selectedColor: Colors.blueAccent,
                                          unselectedColor: Colors.grey),
                                      dataLabelSettings: DataLabelSettings(isVisible: true))                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ,
                                ],
                            ),
                          ),


                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    // flex: 5,
                    child: Card(
                      color: Theme.of(context).cardColor,
                      child: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: SfCartesianChart(
                              primaryXAxis: CategoryAxis(),
                              // Chart title
                              title: ChartTitle(text: 'Daily Users'),
                              // Enable legend
                              legend: Legend(isVisible: true),
                              // Enable tooltip
                              tooltipBehavior: TooltipBehavior(enable: true),
                              series: <ChartSeries<UserStats, String>>[
                                LineSeries<UserStats, String>(
                                    dataSource: usersStats,
                                    xValueMapper: (UserStats stats, _) => '${DateFormat("MMM dd").format(stats.createdAt)} ',
                                    yValueMapper: (UserStats stats, _) => stats.users,
                                    name: 'Line Series',

                                    color: Colors.yellow,
                                    dataLabelSettings: DataLabelSettings(isVisible: true)
                                ),
                                SplineAreaSeries(
                                    dataSource: usersStats,
                                    xValueMapper: (UserStats stats, _) => '${DateFormat("MMM dd").format(stats.createdAt)} ',
                                    yValueMapper: (UserStats stats, _) => stats.users,
                                    name: 'Spline Area',

                                    color: Colors.blueAccent,
                                    dataLabelSettings: DataLabelSettings(isVisible: true)
                                ),
                              ],
                            ),
                          ),


                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Flexible(
                        // flex: 5,
                        child: Container(
                          height:queryData.size.width /4,
                          child: Card(
                            color: Theme.of(context).cardColor,
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  TextWidget(text: 'All Orders', color: color,textSize: 20,),

                                  Padding(
                                    padding: EdgeInsets.all(16),
                                    child: AspectRatio(
                                      aspectRatio: 16/9,
                                      /*aspectRatio: 16 / 9,*/
                                      child: DChartPie(
                                        data: [
                                          {'domain': 'Cancelled', 'measure': cancelled},
                                          {'domain': 'Delivered', 'measure': delivered},
                                          {'domain': 'Pending', 'measure': pending},
                                        ],
                                        fillColor: (pieData, index) {
                                          switch (pieData['domain']) {
                                            case 'Cancelled':
                                              return Colors.red;
                                            case 'Delivered':
                                              return Colors.green;
                                            default:
                                              return Colors.orangeAccent;
                                          }
                                        },
                                        pieLabel: (pieData, index) {
                                          return "${pieData['measure']}";
                                        },
                                        labelPosition: PieLabelPosition.inside,
                                        labelFontSize: (queryData.size.width / 40).round(),
                                        labelColor: color,
                                        donutWidth: 200,
                                      ),
                                    ),
                                  ),
                                  Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      TextWidget(text: 'Delivered', color: color,textSize: queryData.size.width / 90,),
                                      Icon(Icons.circle,color: Colors.green,size: queryData.size.width / 90,),
                                      SizedBox(width: 10,),
                                      TextWidget(text: 'Cancelled', color: color,textSize: queryData.size.width / 90,),
                                      Icon(Icons.circle,color: Colors.red,size:queryData.size.width / 90,),
                                      SizedBox(width: 10,),
                                      TextWidget(text: 'Pending', color: color,textSize: queryData.size.width / 90,),
                                      Icon(Icons.circle,color: Colors.orange,size:queryData.size.width / 90,),
                                    ],
                                  ),
                                ],
                              ),
                            ),

                          ),
                        ),
                      ),
                      Flexible(
                        // flex: 5,
                        child: Container(
                          height:queryData.size.width /4,
                          child: Card(
                            color: Theme.of(context).cardColor,
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                children: [
                                  TextWidget(text: 'Rating: ${rating}', color: color, textSize: queryData.size.width /60, isTitle:true),
                                  RatingBar.builder(
                                  initialRating: rating!,
                                  minRating: 1,
                                  direction: Axis.horizontal,
                                  allowHalfRating: true,
                                  itemCount: 5,
                                    itemSize: queryData.size.width /30,
                                  ignoreGestures: true,
                                  itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
                                  itemBuilder: (context, _) => Icon(
                                  Icons.star,
                                  color: Colors.amber,
                                  ),
                                  onRatingUpdate: (rating) {
                                  },
                                  ),
                                  TextWidget(text: 'Comments', color: color, textSize: queryData.size.width /60, isTitle:true),
                                  Container(
                                    height:queryData.size.width /7,
                                    child: const SingleChildScrollView(
                                      scrollDirection: Axis.vertical,//.horizontal
                                      child: commentList(isInDashboard: false,),
                                    ),
                                  ),
                                ],
                              ),
                            ),

                          ),
                        ),
                      ),
                      Flexible(
                        child: Container(
                          height:queryData.size.width /4,
                          child: Card(
                            color: Theme.of(context).cardColor,
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  StreamBuilder<QuerySnapshot>(
                                      stream: FirebaseFirestore.instance.collection('orders').snapshots(),
                                      builder: (context, snapshot) {
                                        if (!snapshot.hasData) { // if snapshot has no data this is going to run
                                          return Container(
                                              alignment: FractionalOffset.center,
                                              child: CircularProgressIndicator());
                                        }
                                        else{ // if snapshot has data this is going to run
                                          int orders = snapshot.data!.docs.length;
                                          return Row(
                                            children: [
                                              TextWidget(text: 'Total Sales', color: color, textSize: queryData.size.width /40, ),
                                              Spacer(),
                                              TextWidget(text: '₱${allSales.toString().replaceAllMapped(reg, mathFunc)}', color: color, textSize: queryData.size.width /30, isTitle:true),
                                            ],
                                          );
                                        }
                                      }
                                  ),
                                  StreamBuilder<QuerySnapshot>(
                                      stream: FirebaseFirestore.instance.collection('users').snapshots(),
                                      builder: (context, snapshot) {
                                        if (!snapshot.hasData) { // if snapshot has no data this is going to run
                                          return Container(
                                              alignment: FractionalOffset.center,
                                              child: CircularProgressIndicator());
                                        }
                                        else{ // if snapshot has data this is going to run
                                          int customers = snapshot.data!.docs.length;
                                          return Row(
                                            children: [
                                              TextWidget(text: 'Customers', color: color, textSize:  queryData.size.width / 40, ),
                                              Spacer(),
                                              TextWidget(text: '${customers.toString().replaceAllMapped(reg, mathFunc)}', color: color, textSize: queryData.size.width / 30, isTitle:true),
                                            ],
                                          );
                                        }
                                      }
                                  ),
                                  StreamBuilder<QuerySnapshot>(
                                      stream: FirebaseFirestore.instance.collection('products').snapshots(),
                                      builder: (context, snapshot) {
                                        if (!snapshot.hasData) { // if snapshot has no data this is going to run
                                          return Container(
                                              alignment: FractionalOffset.center,
                                              child: CircularProgressIndicator());
                                        }
                                        else{ // if snapshot has data this is going to run
                                          int products = snapshot.data!.docs.length;
                                          return Row(
                                            children: [
                                              TextWidget(text: 'Products', color: color, textSize:  queryData.size.width / 40, ),
                                              Spacer(),
                                              TextWidget(text: '${products.toString().replaceAllMapped(reg, mathFunc)}', color: color, textSize: queryData.size.width / 30, isTitle:true),
                                            ],
                                          );
                                        }
                                      }
                                  ),
                                  StreamBuilder<QuerySnapshot>(
                                      stream: FirebaseFirestore.instance.collection('orders').snapshots(),
                                      builder: (context, snapshot) {
                                        if (!snapshot.hasData) { // if snapshot has no data this is going to run
                                          return Container(
                                              alignment: FractionalOffset.center,
                                              child: CircularProgressIndicator());
                                        }
                                        else{ // if snapshot has data this is going to run
                                          int orders = snapshot.data!.docs.length;
                                          return Row(
                                            children: [
                                              TextWidget(text: 'Orders', color: color, textSize: queryData.size.width / 40, ),
                                              Spacer(),
                                              TextWidget(text: '${orders.toString().replaceAllMapped(reg, mathFunc)}', color: color, textSize: queryData.size.width /30, isTitle:true),



                                            ],
                                          );
                                        }
                                      }
                                  ),
                                ],
                              ),
                            ),

                          ),
                        ),
                      ),

                    ],
                  ),
                ),
              ],
            ),
          ],
        ),

      ),

    );
  }
}