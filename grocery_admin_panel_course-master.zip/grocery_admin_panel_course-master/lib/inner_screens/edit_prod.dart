import 'dart:developer';
import 'dart:io';
import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:grocery_admin_panel/Screens/loading_manager.dart';
import 'package:grocery_admin_panel/controllers/MenuController.dart';
import 'package:grocery_admin_panel/services/global_method.dart';
import 'package:grocery_admin_panel/services/utils.dart';
import 'package:grocery_admin_panel/widgets/buttons.dart';
import 'package:grocery_admin_panel/widgets/header.dart';
import 'package:grocery_admin_panel/widgets/side_menu.dart';
import 'package:grocery_admin_panel/widgets/text_widget.dart';
import 'package:iconly/iconly.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../responsive.dart';


class EditProductScreen extends StatefulWidget {
  const EditProductScreen(
      {Key? key,
      required this.id,
      required this.title,
      required this.price,
      required this.salePrice,
      required this.description,
      required this.tips,
      required this.productCat,
      required this.imageUrl,
      required this.stocks,
      required this.isOnSale,
      required this.isPiece,
      required this.isBestSeller,  })
      : super(key: key);

  final String id, title, price, productCat, imageUrl,  description,tips, stocks;
  final bool isPiece, isOnSale, isBestSeller;
  final double salePrice;

  @override
  _EditProductScreenState createState() => _EditProductScreenState();
}

class _EditProductScreenState extends State<EditProductScreen> {
  final _formKey = GlobalKey<FormState>();
  // Title and price controllers
  late final TextEditingController _titleController, _priceController,_tipsController,_descriptionController ,_stocksController;
  // Category
  late String _catValue;
  // Sale
  String? _salePercent;
  late String percToShow;
  late double _salePrice;
  late bool _isOnSale, _isBestSeller;
  String? url;
  String? filename;
  // Image
  File? _pickedImage;
  Uint8List webImage = Uint8List(10);
  late String _imageUrl;
  // kg or Piece,
  late int val;
  late bool _isPiece;
  // while loading
  bool _isLoading = false;
  @override
  void initState() {
    // set the price and title initial values and initialize the controllers
    _priceController = TextEditingController(text: widget.price);
    _titleController = TextEditingController(text: widget.title);
    _tipsController = TextEditingController(text: widget.tips);
    _descriptionController = TextEditingController(text: widget.description);
    _stocksController = TextEditingController(text: widget.stocks);
    // Set the variables
    _isBestSeller = widget.isBestSeller;
    _salePrice = widget.salePrice;
    _catValue = widget.productCat;
    _isOnSale = widget.isOnSale;
    _isPiece = widget.isPiece;
    val = _isPiece ? 2 : 1;
    _imageUrl = widget.imageUrl;
    // Calculate the percentage
    percToShow = (100 -
                (_salePrice * 100) /
                    double.parse(
                        widget.price)) // WIll be the price instead of 1.88
            .round()
            .toStringAsFixed(1) +
        '%';
    super.initState();
  }

  @override
  void dispose() {
    // Dispose the controllers
    _priceController.dispose();
    _titleController.dispose();
    super.dispose();
  }

  void _updateProduct() async {
    final isValid = _formKey.currentState!.validate();
    FocusScope.of(context).unfocus();

    if (isValid) {
      _formKey.currentState!.save();

      try {
        Uri? imageUri;
        setState(() {
          _isLoading = true;
        });
        if (_pickedImage != null) {

          UploadTask task = FirebaseStorage.instance
              .ref()
              .child("files/$filename")
              .putData(webImage);
          var dowurl = await (await task).ref.getDownloadURL();
          url = dowurl.toString();
        }
        await FirebaseFirestore.instance
            .collection('products')
            .doc(widget.id)
            .update({
          'title': _titleController.text,
          'description': _descriptionController.text,
          'tips': _tipsController.text,
          'price': _priceController.text,
          'salePrice': _salePrice,
          'stocks': _stocksController.text,
          'imageUrl': _pickedImage == null ? widget.imageUrl : url,
          'productCategoryName': _catValue,
          'isOnSale': _isOnSale,
          'isPiece': _isPiece,
          'isBestSeller':_isBestSeller,
        });
        await Fluttertoast.showToast(
          msg: "Product has been updated",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
        );
      } on FirebaseException catch (error) {
        GlobalMethods.errorDialog(
            subtitle: '${error.message}', context: context);
        setState(() {
          _isLoading = false;
        });
      } catch (error) {
        GlobalMethods.errorDialog(subtitle: '$error', context: context);
        setState(() {
          _isLoading = false;
        });
      } finally {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Utils(context).getTheme;
    final color = theme == true ? Colors.white : Colors.black;
    final _scaffoldColor = Theme.of(context).scaffoldBackgroundColor;
    Size size = Utils(context).getScreenSize;

    var inputDecoration = InputDecoration(
      filled: true,
      fillColor: _scaffoldColor,
      border: InputBorder.none,
      focusedBorder: OutlineInputBorder(
        borderSide: BorderSide(
          color: color,
          width: 1.0,
        ),
      ),
    );
    return Scaffold(
     key: context.read<MenuController>().getEditProductscaffoldKey,
     drawer: const SideMenu(),
      body: LoadingManager(
        isLoading: _isLoading,
        child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
        if (Responsive.isDesktop(context))
        const Expanded(
        child: SideMenu(),
        ),
          Expanded(
          flex: 5,
          child: SingleChildScrollView(
            child: Center(
              child: Column(
                children: [
                 Header(
                   showTexField: false,
                   fct: () {
                     context
                        .read<MenuController>()
                         .controlEditProductsMenu();
                   },
                 ),
                Container(
                  width: size.width > 650 ? 650 : size.width,
                  color: Theme.of(context).cardColor,
                  padding: const EdgeInsets.all(16),
                  margin: const EdgeInsets.all(16),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        TextWidget(
                          text: 'Product Image:',
                          color: color,
                          isTitle: true,
                        ),
                        Center(
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Container(
                              height: size.width > 650
                                  ? 350
                                  : size.width * 0.45,
                              decoration: BoxDecoration(
                                color: Theme.of(context)
                                    .scaffoldBackgroundColor,
                                borderRadius:
                                BorderRadius.circular(12.0),
                              ),
                              child:  ClipRRect(
                                borderRadius: const BorderRadius.all(
                                    Radius.circular(12)),
                                child: _pickedImage == null
                                    ? Image.network(widget.imageUrl)
                                    : (kIsWeb)
                                    ? Image.memory(webImage,
                                    fit: BoxFit.fill)
                                    : Image.file(_pickedImage!,
                                    fit: BoxFit.fill),
                              ),
                            ),
                          ),
                        ),
                        TextWidget(
                          text: 'Product Title',
                          color: color,
                          isTitle: true,
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        TextFormField(
                          controller: _titleController,
                          key: const ValueKey('Title'),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return 'Please enter a Title';
                            }
                            return null;
                          },
                          decoration: inputDecoration,
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        TextWidget(
                          text: 'Product Description:',
                          color: color,
                          isTitle: true,
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        TextFormField(
                          maxLines: 8,
                          controller: _descriptionController,

                          validator: (value) {
                            if (value!.isEmpty) {
                              return 'Please enter a Description';
                            }
                            return null;
                          },
                          decoration: inputDecoration,
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        TextWidget(
                          text: 'Product Caretips:',
                          color: color,
                          isTitle: true,
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        TextFormField(
                          maxLines: 8,
                          controller: _tipsController,
                          validator: (value) {
                            if (value!.isEmpty) {
                              return 'Enter product caretipes type N/A if none';
                            }
                            return null;
                          },
                          decoration: inputDecoration,
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            TextWidget(
                              text: 'Price:',
                              color: color,
                              isTitle: true,
                            ),
                            TextWidget(
                              text: 'Stocks:',
                              color: color,
                              isTitle: true,
                            ),

                            TextWidget(
                              text: 'Category:',
                              color: color,
                              isTitle: true,
                            ),

                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [

                            SizedBox(
                              width: 200,
                              child: TextFormField(
                                controller: _priceController,
                                key: const ValueKey('Price \$'),
                                keyboardType: TextInputType.number,
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'Price is missed';
                                  }
                                  return null;
                                },
                                inputFormatters: <
                                    TextInputFormatter>[
                                  FilteringTextInputFormatter.allow(
                                      RegExp(r'[0-9.]')),
                                ],
                                decoration: inputDecoration,
                              ),
                            ),
                            SizedBox(
                              width: 200,
                              child: TextFormField(
                                controller: _stocksController,
                                key: const ValueKey('Stocks \$'),
                                keyboardType: TextInputType.number,
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'Stocks is missed';
                                  }
                                  return null;
                                },
                                inputFormatters: <
                                    TextInputFormatter>[
                                  FilteringTextInputFormatter.allow(
                                      RegExp(r'[0-9.]')),
                                ],
                                decoration: inputDecoration,
                              ),
                            ),
                            ////////////



                            // Drop down menu code here
                            SizedBox(
                                height: 50,
                                width: 200,
                                child: catDropDownWidget(),),


                          ],
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Row(
                              children: [
                                TextWidget(
                                  text: 'Unit: ',
                                  color: color,
                                  isTitle: true,
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                TextWidget(
                                  text: 'KG',
                                  color: color,
                                ),
                                Radio(
                                  value: 1,
                                  groupValue: val,
                                  onChanged: (valuee) {
                                    setState(() {
                                      val = 1;
                                      _isPiece = false;
                                    });
                                  },
                                  activeColor: Colors.green,
                                ),
                                TextWidget(
                                  text: 'Piece',
                                  color: color,
                                ),
                                Radio(
                                  value: 2,
                                  groupValue: val,
                                  onChanged: (valuee) {
                                    setState(() {
                                     val = 2;
                                      _isPiece = true;
                                    });
                                  },
                                  activeColor: Colors.green,
                                ),
                              ],
                            ),
                            TextWidget(
                              text: '|',
                              color: color,
                              isTitle: true,
                            ),
                            Row(
                              children: [
                                Checkbox(
                                  value: _isOnSale,
                                  onChanged: (newValue) {
                                    setState(() {
                                      _isOnSale = newValue!;
                                    });
                                  },
                                ),
                                const SizedBox(
                                  width: 5,
                                ),

                                TextWidget(
                                  text: 'Sale: ',
                                  color: color,
                                  isTitle: true,
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 5,
                            ),
                            AnimatedSwitcher(
                              duration: const Duration(seconds: 1),
                              child: !_isOnSale
                                  ? Container()
                                  : Row(
                                children: [
                                  TextWidget(
                                      text: "\$" +
                                          _salePrice
                                              .toStringAsFixed(2),
                                      color: color),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  salePourcentageDropDownWidget(
                                      color),
                                ],
                              ),
                            ),
                            TextWidget(
                              text: '|',
                              color: color,
                              isTitle: true,
                            ),
                            //BestSeller
                            Row(
                              children: [
                                Checkbox(
                                  value: _isBestSeller,
                                  onChanged: (newValue) {
                                    setState(() {
                                      _isBestSeller = newValue!;
                                    });
                                  },
                                ),
                                const SizedBox(
                                  width: 5,
                                ),
                                TextWidget(
                                  text: 'Best Seller',
                                  color: color,
                                  isTitle: true,
                                ),
                              ],
                            ),
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.all(18.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              ButtonsWidget(
                                onPressed: () async {
                                  GlobalMethods.warningDialog(
                                      title: 'Delete?',
                                      subtitle: 'Press okay to confirm',
                                      fct: () async {
                                        await FirebaseFirestore.instance
                                            .collection('products')
                                            .doc(widget.id)
                                            .delete();
                                        await Fluttertoast.showToast(
                                          msg: "Product has been deleted",
                                          toastLength: Toast.LENGTH_LONG,
                                          gravity: ToastGravity.CENTER,
                                          timeInSecForIosWeb: 1,
                                        );
                                        while (Navigator.canPop(context)) {
                                          Navigator.pop(context);
                                        }
                                      },
                                      context: context);
                                },
                                text: 'Delete',
                                icon: IconlyBold.danger,
                                backgroundColor: Colors.red.shade700,
                              ),
                              Expanded(
                                  flex: 1,
                                  child: Column(
                                    children: [
                                      FittedBox(
                                        child: TextButton(
                                          onPressed: () {
                                            _pickImage();
                                          },
                                          child: TextWidget(
                                            text: 'Update image',
                                            color: Colors.blue,
                                          ),
                                        ),
                                      ),
                                    ],
                                  )),
                              ButtonsWidget(
                                onPressed: () {
                                  _updateProduct();
                                },
                                text: 'Update',
                                icon: IconlyBold.setting,
                                backgroundColor: Colors.blue,
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
        ],
     ),

    ),
    );
  }

  DropdownButtonHideUnderline salePourcentageDropDownWidget(Color color) {
    return DropdownButtonHideUnderline(
      child: DropdownButton<String>(
        style: TextStyle(color: color),
        items: const [
          DropdownMenuItem<String>(
            child: Text('10%'),
            value: '10',
          ),
          DropdownMenuItem<String>(
            child: Text('15%'),
            value: '15',
          ),
          DropdownMenuItem<String>(
            child: Text('25%'),
            value: '25',
          ),
          DropdownMenuItem<String>(
            child: Text('50%'),
            value: '50',
          ),
          DropdownMenuItem<String>(
            child: Text('75%'),
            value: '75',
          ),
          DropdownMenuItem<String>(
            child: Text('0%'),
            value: '0',
          ),
        ],

        onChanged: (value) {
          if (value == '0') {

            setState(() {
              _isOnSale = false;
            });
          } else {
            setState(() {
              _salePercent = value;
              _salePrice = double.parse(widget.price) -
                  (double.parse(value!) * double.parse(widget.price) / 100);
            });
          }
        },
        hint: Text(_salePercent ?? percToShow),
        value: _salePercent,
      ),
    );
  }

  Widget catDropDownWidget() {
    final color = Utils(context).color;
    return Container(
      color: Theme.of(context).scaffoldBackgroundColor,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: DropdownButtonHideUnderline(
          child: DropdownButton<String>(
            style: TextStyle(
              color: color,
              fontWeight: FontWeight.w600,
              fontSize: 18,
            ),
            items: [
              DropdownMenuItem<String>(
                child: Text('Indoor'),
                value: 'Indoor',
              ),
              DropdownMenuItem<String>(
                child: Text('Outdoor'),
                value: 'Outdoor',
              ),
              DropdownMenuItem<String>(
                child: Text('Pots'),
                value: 'Pots',
              ),
              DropdownMenuItem<String>(
                child: Text('Seeds'),
                value: 'Seeds',
              ),
              DropdownMenuItem<String>(
                child: Text('Soil'),
                value: 'Soil',
              ),
              DropdownMenuItem<String>(
                child: Text('Fertilizer'),
                value: 'Fertilizer',
              ),
            ],
            onChanged: (value) {
              setState(() {
                _catValue = value!;
              });
            },
            hint: const Text('Select a Category'),
            value: _catValue,
          ),
        ),
      ),
    );
  }

  Future<void> _pickImage() async {
    // MOBILE
    if (!kIsWeb) {
      final ImagePicker _picker = ImagePicker();
      XFile? image = await _picker.pickImage(source: ImageSource.gallery);

      if (image != null) {
        var selected = File(image.path);

        setState(() {
          _pickedImage = selected;
        });
      } else {
        log('No file selected');
        // showToast("No file selected");
      }
    }
    // WEB
    else if (kIsWeb) {
      FilePickerResult? result = await FilePicker.platform.pickFiles();
      webImage = result!.files.first.bytes!;
      filename = result.files.first.name;
      if (result != null) {
        setState(() {
          _pickedImage = File("a");
          webImage;
        });
      } else {
        log('No file selected');
      }
    } else {
      log('Perm not granted');
    }
  }
}
