
const defaultPadding = 10.0;
