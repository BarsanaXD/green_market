import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:grocery_admin_panel/services/utils.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

import '../services/global_method.dart';
import 'text_widget.dart';

class OrdersWidget extends StatefulWidget {
  const OrdersWidget(
      {Key? key,
      required this.price,
      required this.orderId,
      required this.totalPrice,
      required this.productId,
      required this.userId,
      required this.imageUrl,
      required this.userName,
      required this.quantity,
      required this.orderDate,
      required this.cancelled,
      required this.delivered,
      })
      : super(key: key);
  final double price, totalPrice;
  final bool cancelled,delivered;
  final String productId, userId, imageUrl, userName,orderId;
  final int quantity;
  final Timestamp orderDate;
  @override
  _OrdersWidgetState createState() => _OrdersWidgetState();
}
class _OrdersWidgetState extends State<OrdersWidget> {
  late String orderDateStr;
  @override
  void initState() {
    var postDate = widget.orderDate.toDate();
    orderDateStr = '${DateFormat.yMEd().add_jms().format(postDate)} ';
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    final theme = Utils(context).getTheme;
    Color color = theme == true ? Colors.white : Colors.black;
    Size size = Utils(context).getScreenSize;
    return Material(
      borderRadius: BorderRadius.circular(8.0),
      color: Theme.of(context).cardColor.withOpacity(0.4),
      child: Card(
        color: Theme.of(context).canvasColor,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Flexible(
                flex: size.width < 650 ? 3 : 1,
                child: Image.network(
                  widget.imageUrl,
                  fit: BoxFit.fill,
                ),
              ),
              const SizedBox(
                width: 12,
              ),
              Expanded(
                flex: 10,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    TextWidget(
                      text:
                          '${widget.quantity}X For \₱${widget.price.toStringAsFixed(2)}',
                      color: color,
                      textSize: 16,
                      isTitle: true,
                    ),
                    FittedBox(
                      child: Row(
                        children: [
                          TextWidget(
                            text: 'By',
                            color: Colors.blue,
                            textSize: 16,
                            isTitle: true,
                          ),
                        Text('  ${widget.userName}')
                        ],
                      ),
                    ),
                    Text(
                      orderDateStr,
                    ),
                    Visibility(
                      visible: widget.cancelled ? true:false,
                      child:  TextWidget(
                          text: 'Status: Cancelled',
                          color: color,
                          textSize: 18),
                    ),
                    Visibility(
                      visible: widget.delivered ?true:false,
                      child:  TextWidget(
                          text: 'Status: Delivered',
                          color: color,
                          textSize: 16),
                    ),
                  ],
                ),
              ),
              Visibility(
                visible: widget.cancelled? true:false,
                child:  TextWidget(
                    text: 'Cancelled',
                    color: color,
                    textSize: 16),
              ),
              Visibility(
                visible: widget.delivered ? true:false,
                child:  TextWidget(
                    text: 'Delivered',
                    color: color,
                    textSize: 16),
              ),
              Visibility(
                visible: widget.cancelled || widget.delivered ? false:true,
                child: Material(
                  color: Colors.green,
                  borderRadius: BorderRadius.circular(8),
                  child: TextButton(
                    style: TextButton.styleFrom(
                      textStyle: TextStyle(fontSize: 20,color: color),
                    ),
                    onPressed: () async {
                      GlobalMethods.warningDialog(
                          title: 'Deliver?',
                          subtitle: 'Press okay to confirm',
                          fct: () async {
                            await FirebaseFirestore.instance
                                .collection('orders')
                                .doc(widget.orderId)
                                .update(
                                {
                                  'orderRecieved':Timestamp.now(),
                                  'delivered': true,
                                  'cancelled': false,
                                }
                            );
                            await Fluttertoast.showToast(
                              msg: "Order has been Delivered",
                              toastLength: Toast.LENGTH_LONG,
                              gravity: ToastGravity.CENTER,
                              timeInSecForIosWeb: 1,
                            );

                          },
                          context: context);

                    },
                    child: TextWidget(text:'Deliver', color: color, textSize: 20),
                  ),
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }
}
